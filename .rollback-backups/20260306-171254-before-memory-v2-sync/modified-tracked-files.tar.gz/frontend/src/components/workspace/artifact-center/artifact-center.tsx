"use client";

import { LayersIcon } from "lucide-react";

import { Button } from "@/components/ui/button";
import { useArtifacts } from "@/components/workspace/artifacts/context";
import { Tooltip } from "@/components/workspace/tooltip";
import { useI18n } from "@/core/i18n/hooks";

export function ArtifactCenter({ threadId }: { threadId: string }) {
  void threadId;
  const { t } = useI18n();
  const { artifacts, deselect, setOpen: setArtifactsOpen, panelView, setPanelView } =
    useArtifacts();

  return (
    <Tooltip content={t.artifactCenter.triggerTooltip}>
      <Button
        className="text-muted-foreground hover:text-foreground data-[active=true]:bg-accent data-[active=true]:text-foreground"
        variant="ghost"
        data-active={panelView === "center"}
        onClick={() => {
          deselect();
          setPanelView("center");
          setArtifactsOpen(true);
        }}
      >
        <LayersIcon className="size-4" />
        {t.artifactCenter.trigger}
        {artifacts.length > 0 ? ` (${artifacts.length})` : ""}
      </Button>
    </Tooltip>
  );
}
