import { XIcon } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import type { GroupImperativeHandle } from "react-resizable-panels";

import { Button } from "@/components/ui/button";
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";
import { useI18n } from "@/core/i18n/hooks";
import { env } from "@/env";
import { cn } from "@/lib/utils";

import {
  ArtifactDirectoryTree,
  ArtifactFileList,
  ArtifactFileDetail,
  useArtifacts,
} from "../artifacts";
import { useThread } from "../messages/context";

const CLOSE_MODE = { chat: 100, artifacts: 0 };
const OPEN_MODE = { chat: 60, artifacts: 40 };

const ChatBox: React.FC<{ children: React.ReactNode; threadId: string }> = ({
  children,
  threadId,
}) => {
  const { t } = useI18n();
  const { thread } = useThread();
  const layoutRef = useRef<GroupImperativeHandle>(null);
  const {
    artifacts,
    open: artifactsOpen,
    setOpen: setArtifactsOpen,
    setArtifacts,
    select: selectArtifact,
    selectedArtifact,
    panelView,
    setPanelView,
  } = useArtifacts();

  const [autoSelectFirstArtifact, setAutoSelectFirstArtifact] = useState(true);
  useEffect(() => {
    setArtifacts(thread.values.artifacts ?? []);
    if (
      env.NEXT_PUBLIC_STATIC_WEBSITE_ONLY === "true" &&
      autoSelectFirstArtifact
    ) {
      if (thread?.values?.artifacts?.length > 0) {
        setAutoSelectFirstArtifact(false);
        selectArtifact(thread.values.artifacts[0]!);
      }
    }
  }, [
    autoSelectFirstArtifact,
    selectArtifact,
    setArtifacts,
    thread.values.artifacts,
  ]);

  const artifactPanelOpen = useMemo(() => {
    if (env.NEXT_PUBLIC_STATIC_WEBSITE_ONLY === "true") {
      return artifactsOpen && artifacts?.length > 0;
    }
    return artifactsOpen;
  }, [artifactsOpen, artifacts]);

  useEffect(() => {
    if (layoutRef.current) {
      if (artifactPanelOpen) {
        layoutRef.current.setLayout(OPEN_MODE);
      } else {
        layoutRef.current.setLayout(CLOSE_MODE);
      }
    }
  }, [artifactPanelOpen]);

  return (
    <ResizablePanelGroup
      id="workspace-chat-panel-group"
      orientation="horizontal"
      defaultLayout={{ chat: 100, artifacts: 0 }}
      groupRef={layoutRef}
    >
      <ResizablePanel className="relative" defaultSize={100} id="chat">
        {children}
      </ResizablePanel>
      <ResizableHandle
        id="workspace-chat-panel-handle"
        className={cn(
          "opacity-33 hover:opacity-100",
          !artifactPanelOpen && "pointer-events-none opacity-0",
        )}
      />
      <ResizablePanel
        className={cn(
          "transition-all duration-300 ease-in-out",
          !artifactsOpen && "opacity-0",
        )}
        id="artifacts"
      >
        <div
          className={cn(
            "h-full p-4 transition-transform duration-300 ease-in-out",
            artifactPanelOpen ? "translate-x-0" : "translate-x-full",
          )}
        >
          {selectedArtifact ? (
            <ArtifactFileDetail
              className="size-full"
              filepath={selectedArtifact}
              threadId={threadId}
            />
          ) : (
            <div className="relative size-full min-w-0 overflow-hidden rounded-lg border">
              <div
                className={cn(
                  "absolute inset-0 flex flex-col transition-all duration-300 ease-out",
                  panelView === "directory"
                    ? "translate-x-0 opacity-100"
                    : "-translate-x-6 opacity-0 pointer-events-none",
                )}
              >
                <div className="flex items-center justify-between border-b px-3 py-2 text-xs">
                  <span className="font-medium">{t.common.directoryTree}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">
                      {thread.values.artifacts?.length ?? 0}
                      {t.common.filesSuffix}
                    </span>
                    <Button
                      size="icon-sm"
                      variant="ghost"
                      onClick={() => {
                        setArtifactsOpen(false);
                      }}
                    >
                      <XIcon className="size-4" />
                    </Button>
                  </div>
                </div>
                <ArtifactDirectoryTree
                  files={thread.values.artifacts ?? []}
                  selectedPath={selectedArtifact}
                  onOpenFile={(path) => {
                    selectArtifact(path);
                    setPanelView("directory");
                    setArtifactsOpen(true);
                  }}
                />
              </div>
              <div
                className={cn(
                  "absolute inset-0 flex flex-col transition-all duration-300 ease-out",
                  panelView === "center"
                    ? "translate-x-0 opacity-100"
                    : "translate-x-6 opacity-0 pointer-events-none",
                )}
              >
                <div className="flex items-center justify-between border-b px-3 py-2 text-xs">
                  <span className="font-medium">{t.artifactCenter.title}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">
                      {thread.values.artifacts?.length ?? 0}
                      {t.common.filesSuffix}
                    </span>
                    <Button
                      size="icon-sm"
                      variant="ghost"
                      onClick={() => {
                        setArtifactsOpen(false);
                      }}
                    >
                      <XIcon className="size-4" />
                    </Button>
                  </div>
                </div>
                <div className="min-h-0 flex-1 overflow-y-auto p-3">
                  {thread.values.artifacts?.length ? (
                    <ArtifactFileList
                      className="gap-3"
                      files={thread.values.artifacts}
                      threadId={threadId}
                      onOpenFile={(path) => {
                        selectArtifact(path);
                        setPanelView("center");
                        setArtifactsOpen(true);
                      }}
                    />
                  ) : (
                    <div className="text-muted-foreground flex h-full min-h-36 items-center justify-center rounded-md border border-dashed px-4 text-sm">
                      {t.artifactCenter.empty}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </ResizablePanel>
    </ResizablePanelGroup>
  );
};

export { ChatBox };
