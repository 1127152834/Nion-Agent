import {
  createContext,
  useCallback,
  useContext,
  useState,
  type ReactNode,
} from "react";

import { useSidebar } from "@/components/ui/sidebar";
import { env } from "@/env";

export type ArtifactPanelView = "directory" | "center";

export interface ArtifactsContextType {
  artifacts: string[];
  setArtifacts: (artifacts: string[]) => void;

  selectedArtifact: string | null;
  autoSelect: boolean;
  select: (artifact: string, autoSelect?: boolean) => void;
  deselect: () => void;

  open: boolean;
  autoOpen: boolean;
  setOpen: (open: boolean) => void;
  panelView: ArtifactPanelView;
  setPanelView: (view: ArtifactPanelView) => void;
}

const ArtifactsContext = createContext<ArtifactsContextType | undefined>(
  undefined,
);

interface ArtifactsProviderProps {
  children: ReactNode;
}

export function ArtifactsProvider({ children }: ArtifactsProviderProps) {
  const [artifacts, setArtifactsState] = useState<string[]>([]);
  const [selectedArtifact, setSelectedArtifact] = useState<string | null>(null);
  const [autoSelect, setAutoSelect] = useState(true);
  const [open, setOpen] = useState(
    env.NEXT_PUBLIC_STATIC_WEBSITE_ONLY === "true",
  );
  const [autoOpen, setAutoOpen] = useState(true);
  const [panelView, setPanelView] = useState<ArtifactPanelView>("directory");
  const { setOpen: setSidebarOpen } = useSidebar();

  const setArtifacts = useCallback((nextArtifacts: string[]) => {
    const normalized = Array.isArray(nextArtifacts) ? nextArtifacts : [];
    setArtifactsState((previous) => {
      if (previous === normalized) {
        return previous;
      }
      if (previous.length !== normalized.length) {
        return normalized;
      }
      for (let index = 0; index < previous.length; index += 1) {
        if (previous[index] !== normalized[index]) {
          return normalized;
        }
      }
      return previous;
    });
  }, []);

  const select = (artifact: string, autoSelect = false) => {
    setSelectedArtifact(artifact);
    if (env.NEXT_PUBLIC_STATIC_WEBSITE_ONLY !== "true") {
      setSidebarOpen(false);
    }
    if (!autoSelect) {
      setAutoSelect(false);
    }
  };

  const deselect = () => {
    setSelectedArtifact(null);
    setAutoSelect(true);
  };

  const value: ArtifactsContextType = {
    artifacts,
    setArtifacts,

    open,
    autoOpen,
    autoSelect,
    setOpen: (isOpen: boolean) => {
      if (!isOpen && autoOpen) {
        setAutoOpen(false);
        setAutoSelect(false);
      }
      setOpen(isOpen);
    },
    panelView,
    setPanelView,

    selectedArtifact,
    select,
    deselect,
  };

  return (
    <ArtifactsContext.Provider value={value}>
      {children}
    </ArtifactsContext.Provider>
  );
}

export function useArtifacts() {
  const context = useContext(ArtifactsContext);
  if (context === undefined) {
    throw new Error("useArtifacts must be used within an ArtifactsProvider");
  }
  return context;
}
