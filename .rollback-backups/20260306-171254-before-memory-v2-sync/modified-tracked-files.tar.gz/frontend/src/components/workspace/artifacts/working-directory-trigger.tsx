import { FolderIcon } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Tooltip } from "@/components/workspace/tooltip";
import { useI18n } from "@/core/i18n/hooks";

import { useArtifacts } from "./context";

export const WorkingDirectoryTrigger = () => {
  const { t } = useI18n();
  const {
    artifacts,
    deselect,
    setOpen: setArtifactsOpen,
    panelView,
    setPanelView,
  } = useArtifacts();

  return (
    <Tooltip content={t.common.browseWorkspace}>
      <Button
        className="text-muted-foreground hover:text-foreground data-[active=true]:bg-accent data-[active=true]:text-foreground"
        variant="ghost"
        data-active={panelView === "directory"}
        onClick={() => {
          deselect();
          setPanelView("directory");
          setArtifactsOpen(true);
        }}
      >
        <FolderIcon />
        {t.common.workingDirectory}
        {artifacts?.length ? ` (${artifacts.length})` : ""}
      </Button>
    </Tooltip>
  );
};
