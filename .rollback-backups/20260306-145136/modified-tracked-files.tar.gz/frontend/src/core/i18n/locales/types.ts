import type { LucideIcon } from "lucide-react";

type MigrationSettings = {
  modelSettings: Record<string, unknown>;
  toolSettings: Record<string, unknown>;
  skillSettings: Record<string, unknown>;
  retrieval: Record<string, unknown>;
  common: Record<string, unknown>;
};

type ArtifactFileListTranslations = {
  installSkillFailed: string;
  fileTypeSuffix: string;
};

type ArtifactFileDetailTranslations = {
  installSkillFailed: string;
  selectFile: string;
  copyFailed: string;
};

type WorkspaceInputMentionsTranslations = {
  recentLabel: string;
  allSkillsLabel: string;
  directoriesLabel: string;
  filesLabel: string;
  mcpToolsLabel: string;
  mentionHintAt: string;
  mentionHintSlash: string;
  contextLabel: string;
  noMatches: string;
  switchLabel: string;
  completeLabel: string;
  navigateLabel: string;
  selectLabel: string;
  closeLabel: string;
  skillLabel: string;
  searchMcpTools: string;
  noMcpTools: string;
  recentModelsLabel: string;
  allModelsLabel: string;
};

type WorkspaceTodoListTranslations = {
  title: string;
};

type WorkspaceThreadTitleTranslations = {
  untitled: string;
  loading: string;
};

type ToolPresetTranslations = {
  web_search: string;
  web_fetch: string;
  image_search: string;
  ls: string;
  read_file: string;
  write_file: string;
  str_replace: string;
  bash: string;
};

type SettingsConfigToolsSectionTranslations = {
  title: string;
  subtitle: string;
  webConfigTitle: string;
  webConfigSubtitle: string;
  tavilyApiKey: string;
  jinaApiKey: string;
  maxResults: string;
  timeout: string;
  placeholderApiKey: string;
  show: string;
  hide: string;
  testingKey: string;
  keyTestSuccess: string;
  keyTestFailed: string;
  keyTestInvalid: string;
  keyTestInvalidCleared: string;
  keyTestMissing: string;
  keyTestNetwork: string;
  keyTestUnsupported: string;
  hintZh: string;
  hintEn: string;
  customInfoTemplate: string;
  presetTitles: ToolPresetTranslations;
  presetDescriptions: ToolPresetTranslations;
};

type SettingsModelPageTranslations = {
  notSet: string;
  unnamedModel: string;
  providersLabel: string;
  providersSubtitle: string;
  modelsLabel: string;
  modelsSubtitle: string;
  loadConfigFailed: string;
  defaultModelLabel: string;
  helperText: string;
};

type SettingsToolPageTranslations = {
  mcpTitle: string;
  mcpDesc: string;
  addServer: string;
  emptyServer: string;
  remove: string;
  builtInTitle: string;
  builtInDesc: string;
  serverName: string;
  serverNamePlaceholder: string;
  serverDesc: string;
  serverDescPlaceholder: string;
  serverType: string;
  command: string;
  commandPlaceholder: string;
  args: string;
  argsPlaceholder: string;
  url: string;
  urlPlaceholder: string;
  enabled: string;
  cancel: string;
  create: string;
  creating: string;
  loadConfigFailed: string;
  probeDisabled: string;
  probeTesting: string;
  probeRetry: string;
  probeFailed: string;
  probeConnected: string;
  toolsLabel: string;
};

type SettingsSkillPageTranslations = {
  uploadFormatError: string;
  skillInstalled: string;
  uploadFailed: string;
  skillDeleted: string;
  deleteFailed: string;
  createViaChat: string;
  uploading: string;
  uploadPackage: string;
  importFromAgents: string;
  deleteConfirmTitle: string;
  deleteConfirmDescription: string;
  cancelAction: string;
  confirmDeleteAction: string;
};

type SettingsWorkbenchPluginsPageTranslations = {
  title: string;
  description: string;
  installed: string;
  marketplace: string;
  addPlugin: string;
  createViaSkill: string;
  uploadPackage: string;
  uploading: string;
  uploadFormatError: string;
  uploadFailed: string;
  pluginInstalled: string;
  pluginDeleted: string;
  deleteFailed: string;
  deleteConfirmTitle: string;
  deleteConfirmDescription: string;
  cancelAction: string;
  confirmDeleteAction: string;
  emptyTitle: string;
  emptyDescription: string;
  emptyButton: string;
  noDescription: string;
};

type SettingsConfigSaveBarTranslations = {
  dirty: string;
  clean: string;
  discard: string;
  save: string;
  saving: string;
};

type SettingsConfigFieldTipTranslations = {
  ariaLabel: string;
  recommendedZh: string;
  recommendedEn: string;
  riskZh: string;
  riskEn: string;
};

type SettingsConfigEnvironmentVariablesTranslations = {
  title: string;
  subtitle: string;
  key: string;
  value: string;
  add: string;
  remove: string;
  show: string;
  hide: string;
  empty: string;
  invalidKey: string;
  reservedKey: string;
  invalidConfigStorage: string;
};

type SettingsConfigSubagentsTranslations = {
  title: string;
  subtitle: string;
  defaultTimeout: string;
  perAgent: string;
  agentName: string;
  timeout: string;
  add: string;
  remove: string;
  empty: string;
  hint: string;
};

type SettingsConfigModelsTranslations = {
  providersTitle: string;
  providersSubtitle: string;
  createProvider: string;
  providerDetailTitle: string;
  createDetailTitle: string;
  createDetailHint: string;
  providerName: string;
  providerNamePlaceholder: string;
  providerProtocol: string;
  providerProtocolOpenAI: string;
  providerProtocolAnthropic: string;
  apiKey: string;
  apiBase: string;
  apiBasePlaceholder: string;
  apiBasePlaceholderAnthropic: string;
  showApiKey: string;
  hideApiKey: string;
  testConnection: string;
  testingConnection: string;
  fetchingCatalog: string;
  saveProvider: string;
  deleteProvider: string;
  remove: string;
  confirmDeleteTitle: string;
  confirmDeleteAction: string;
  confirmDeleteProvider: string;
  confirmDeleteModel: string;
  advanced: string;
  backToProviderList: string;
  openProviderModels: string;
  backToProviderDetail: string;
  openProvider: string;
  statusConnected: string;
  statusFailed: string;
  statusUntested: string;
  lastTestedAt: string;
  modelCount: string;
  noProvider: string;
  noProviderCtaTitle: string;
  noProviderCtaHint: string;
  goCreateProvider: string;
  modelsTitle: string;
  modelsSubtitle: string;
  modelListTitle: string;
  modelListSubtitle: string;
  createModel: string;
  createModelTitle: string;
  editModelTitle: string;
  backToModelList: string;
  noModelOnList: string;
  openModel: string;
  capabilityReasoning: string;
  capabilityVision: string;
  capabilityVideo: string;
  addFlowTitle: string;
  addFlowHint: string;
  stepChooseProvider: string;
  stepChooseSource: string;
  stepAddAction: string;
  stepChooseProviderHint: string;
  stepChooseSourceHint: string;
  stepAddActionHint: string;
  selectProviderFirstHint: string;
  providerModelsTitle: string;
  providerModelsSubtitle: string;
  addProviderModel: string;
  addProviderModelDialogTitle: string;
  addProviderModelDialogDesc: string;
  backToProviderModels: string;
  noProviderModels: string;
  usingProvider: string;
  selectProvider: string;
  searchModel: string;
  enterToAddModel: string;
  quickAddLabel: string;
  selected: string;
  selectedModelsEmpty: string;
  manualAddedTag: string;
  addSelectedModels: string;
  manualInput: string;
  catalogInput: string;
  adding: string;
  noCatalog: string;
  noModel: string;
  modelName: string;
  modelNamePlaceholder: string;
  modelId: string;
  modelIdPlaceholder: string;
  bindProvider: string;
  unassigned: string;
  legacyImported: string;
  setDefault: string;
  default: string;
  internalName: string;
  internalNamePlaceholder: string;
  maxTokens: string;
  contextWindow: string;
  temperature: string;
  supportsThinking: string;
  supportsVision: string;
  supportsVideo: string;
  expandDetails: string;
  collapseDetails: string;
  inspectModel: string;
  inspectingModel: string;
  modelMissingRequired: string;
  duplicateModelName: string;
  testSuccess: string;
  testFailed: string;
  requireProviderForManualAdd: string;
  requireModelIdForManualAdd: string;
  duplicateModelHint: string;
  metadataFilled: string;
  metadataNotFound: string;
  inspectRequiresProvider: string;
  inspectRequiresModelId: string;
  modelListCollapsedHint: string;
  quickActionsTitle: string;
  quickActionsHint: string;
  cancel: string;
  defaultOpenaiProviderNameTemplate: string;
  defaultAnthropicProviderNameTemplate: string;
  modelFallbackNameTemplate: string;
  addedModelsToastTemplate: string;
};

type SettingsConfigRssTranslations = {
  subtitle: string;
  enabled: string;
  fetchInterval: string;
  maxEntries: string;
  assistantModel: string;
  assistantModelTip: string;
  useDefaultModel: string;
  learningTitle: string;
  maxDocs: string;
  minScore: string;
  tokenBudget: string;
  fetchIntervalTipZh: string;
  fetchIntervalTipEn: string;
  fetchIntervalRecommended: string;
  maxEntriesTipZh: string;
  maxEntriesTipEn: string;
  maxEntriesRecommended: string;
  assistantModelTipZh: string;
  assistantModelTipEn: string;
};

type SettingsConfigSummarizationTranslations = {
  title: string;
  subtitle: string;
  enabled: string;
  model: string;
  useDefaultModel: string;
  triggers: string;
  addTrigger: string;
  triggerType: string;
  triggerValue: string;
  remove: string;
  advanced: string;
  keepType: string;
  keepValue: string;
  noTrigger: string;
  tokensLabel: string;
  messagesLabel: string;
  fractionLabel: string;
};

type SettingsConfigTitleTranslations = {
  title: string;
  subtitle: string;
  enabled: string;
  model: string;
  useDefaultModel: string;
  advanced: string;
  maxWords: string;
  maxChars: string;
};

type SettingsConfigSandboxTranslations = {
  title: string;
  subtitle: string;
  mode: string;
  local: string;
  aio: string;
  custom: string;
  usePath: string;
  usePathPlaceholder: string;
  image: string;
  imagePlaceholder: string;
  port: string;
  autoStart: string;
  advanced: string;
  baseUrl: string;
  baseUrlPlaceholder: string;
  containerPrefix: string;
  idleTimeout: string;
  modeTipZh: string;
  modeTipEn: string;
  customConfiguredHint: string;
};

type SettingsConfigMemoryTranslations = {
  title: string;
  subtitle: string;
  enabled: string;
  extract: string;
  solution: string;
  collective: string;
  compression: string;
  searxng: string;
  evolution: string;
  halfLife: string;
  languages: string;
  soulEnabled: string;
  soulHint: string;
  soulSeedFromGlobal: string;
  soulIncognito: string;
  autoStyleAdaptation: string;
  autoStyleHint: string;
  languageZh: string;
  languageEn: string;
};

type SettingsSkillImportDialogTranslations = {
  scanFailed: string;
  importCompleted: string;
  importFailed: string;
  title: string;
  description: string;
  stepProvider: string;
  stepCandidates: string;
  stepConflicts: string;
  scan: string;
  next: string;
  back: string;
  import: string;
  close: string;
  noCandidates: string;
  selectedCount: string;
  conflictTitle: string;
  action: string;
  targetName: string;
  risk: string;
  pathsTitle: string;
  missingTitle: string;
  summaryTitle: string;
  skip: string;
  overwriteCustom: string;
  rename: string;
  importDirectly: string;
  highRiskTip: string;
  loading: string;
  noneValue: string;
  hasConflict: string;
  summaryLine: string;
  scanning: string;
  importing: string;
};

type SettingsValidationTranslations = {
  rootLabel: string;
  validationFailed: string;
  validationPassed: string;
  validateRequestFailed: string;
  saved: string;
  saveFailed: string;
};

export interface Translations {
  migration: {
    settings: MigrationSettings;
  };

  // Locale meta
  locale: {
    localName: string;
  };

  // Common
  common: {
    home: string;
    settings: string;
    delete: string;
    rename: string;
    share: string;
    openInNewWindow: string;
    close: string;
    more: string;
    search: string;
    download: string;
    thinking: string;
    artifacts: string;
    public: string;
    custom: string;
    notAvailableInDemoMode: string;
    loading: string;
    version: string;
    lastUpdated: string;
    code: string;
    preview: string;
    cancel: string;
    save: string;
    install: string;
    create: string;
    workingDirectory: string;
    browseWorkspace: string;
    directoryTree: string;
    filesSuffix: string;
    noFilesInDirectory: string;
  };

  artifactCenter: {
    trigger: string;
    triggerTooltip: string;
    title: string;
    description: string;
    shortcut: string;
    empty: string;
    workbenchTitle: string;
  };

  artifacts: {
    fileList: ArtifactFileListTranslations;
    fileDetail: ArtifactFileDetailTranslations;
  };

  // Welcome
  welcome: {
    greeting: string;
    description: string;
    createYourOwnSkill: string;
    createYourOwnSkillDescription: string;
  };

  // Clipboard
  clipboard: {
    copyToClipboard: string;
    copiedToClipboard: string;
    failedToCopyToClipboard: string;
    linkCopied: string;
  };

  // Input Box
  inputBox: {
    placeholder: string;
    createSkillPrompt: string;
    addAttachments: string;
    mode: string;
    flashMode: string;
    flashModeDescription: string;
    reasoningMode: string;
    reasoningModeDescription: string;
    proMode: string;
    proModeDescription: string;
    ultraMode: string;
    ultraModeDescription: string;
    reasoningEffort: string;
    reasoningEffortMinimal: string;
    reasoningEffortMinimalDescription: string;
    reasoningEffortLow: string;
    reasoningEffortLowDescription: string;
    reasoningEffortMedium: string;
    reasoningEffortMediumDescription: string;
    reasoningEffortHigh: string;
    reasoningEffortHighDescription: string;
    searchModels: string;
    surpriseMe: string;
    surpriseMePrompt: string;
    suggestions: {
      suggestion: string;
      prompt: string;
      icon: LucideIcon;
    }[];
    suggestionsCreate: (
      | {
          suggestion: string;
          prompt: string;
          icon: LucideIcon;
        }
      | {
          type: "separator";
        }
    )[];
  };

  // Sidebar
  sidebar: {
    recentChats: string;
    newChat: string;
    chats: string;
    demoChats: string;
    agents: string;
    rss: string;
  };

  // Agents
  agents: {
    title: string;
    description: string;
    newAgent: string;
    emptyTitle: string;
    emptyDescription: string;
    chat: string;
    delete: string;
    deleteConfirm: string;
    deleteSuccess: string;
    newChat: string;
    createPageTitle: string;
    createPageSubtitle: string;
    nameStepTitle: string;
    nameStepHint: string;
    nameStepPlaceholder: string;
    nameStepContinue: string;
    nameStepInvalidError: string;
    nameStepAlreadyExistsError: string;
    nameStepCheckError: string;
    nameStepBootstrapMessage: string;
    agentCreated: string;
    startChatting: string;
    backToGallery: string;
  };

  // Breadcrumb
  breadcrumb: {
    workspace: string;
    chats: string;
    rss: string;
  };

  // Workspace
  workspace: {
    officialWebsite: string;
    githubTooltip: string;
    settingsAndMore: string;
    visitGithub: string;
    reportIssue: string;
    contactUs: string;
    about: string;
    inputMentions: WorkspaceInputMentionsTranslations;
    todoList: WorkspaceTodoListTranslations;
    threadTitle: WorkspaceThreadTitleTranslations;
  };

  // Conversation
  conversation: {
    noMessages: string;
    startConversation: string;
  };

  // Chats
  chats: {
    searchChats: string;
  };

  // Page titles (document title)
  pages: {
    appName: string;
    chats: string;
    rss: string;
    newChat: string;
    untitled: string;
  };

  rssReader: {
    title: string;
    entries: string;
    allFeeds: string;
    addFeed: string;
    addFeedDescription: string;
    feedUrlPlaceholder: string;
    feedCategoryPlaceholder: string;
    feedUrlRequired: string;
    feedUrlInvalid: string;
    subscribe: string;
    refresh: string;
    refreshAll: string;
    discoverTitle: string;
    discoverSearchPlaceholder: string;
    discoverEmpty: string;
    discoverLoadFailed: string;
    discoverFeatured: string;
    discoverSubscribed: string;
    discoverAlreadySubscribed: string;
    discoverPreview: string;
    discoverPreviewTitle: string;
    discoverPreviewLoading: string;
    discoverPreviewFailed: string;
    discoverPreviewEmpty: string;
    discoverPreviewRecentEntries: string;
    subscriptionsNavTitle: string;
    discoverNavDescription: string;
    subscriptionsNavDescription: string;
    goToDiscover: string;
    backToSubscriptions: string;
    discoverLanguageLabel: string;
    discoverLanguageAll: string;
    discoverLanguageChinese: string;
    discoverLanguageEnglish: string;
    discoverSortLabel: string;
    discoverSortFeatured: string;
    discoverSortTitle: string;
    discoverSortSite: string;
    discoverFeaturedSectionTitle: string;
    discoverFeaturedSectionDescription: string;
    discoverCategoryBoardTitle: string;
    discoverCategoryBoardDescription: string;
    discoverExploreCategory: string;
    rsshubTool: string;
    rsshubDialogTitle: string;
    rsshubDialogDescription: string;
    rsshubInstancePlaceholder: string;
    rsshubRoutePlaceholder: string;
    rsshubPreviewLabel: string;
    rsshubSearchPlaceholder: string;
    rsshubNoRoutes: string;
    rsshubRouteRequired: string;
    rsshubTemplateLabel: string;
    rsshubNoParamsNeeded: string;
    opmlTool: string;
    opmlDialogTitle: string;
    opmlDialogDescription: string;
    opmlFilterPlaceholder: string;
    opmlSelectFiltered: string;
    opmlClearSelection: string;
    opmlSelectedCount: string;
    opmlNoSource: string;
    opmlImportSelected: string;
    opmlParsed: string;
    opmlParseFailed: string;
    opmlSelectAtLeastOne: string;
    opmlImportSummary: string;
    emptyFeeds: string;
    emptyEntries: string;
    loadingEntries: string;
    loadingEntry: string;
    loadingMore: string;
    loadMoreHint: string;
    filterAll: string;
    filterUnread: string;
    filterStarred: string;
    markRead: string;
    markUnread: string;
    star: string;
    unstar: string;
    askAI: string;
    summarize: string;
    translate: string;
    askAIPrompt: string;
    summarizePrompt: string;
    translatePrompt: string;
    generateSummary: string;
    generateTranslation: string;
    summaryTitle: string;
    translationTitle: string;
    summaryFailed: string;
    translationFailed: string;
    openOriginal: string;
    backToList: string;
    aiPanelTitle: string;
    aiPanelDescription: string;
    assistantFloatingDescription: string;
    assistantOpen: string;
    assistantClose: string;
    assistantNewChat: string;
    assistantWelcomeTitle: string;
    assistantWelcomeDescription: string;
    assistantAskSelection: string;
    assistantThinking: string;
    assistantInputPlaceholder: string;
    assistantSend: string;
    assistantRestoreSelection: string;
    selectionCopy: string;
    selectionCopied: string;
    feedAdded: string;
    feedDeleted: string;
    feedRefreshed: string;
    feedAddFailed: string;
    feedDeleteFailed: string;
    feedRefreshFailed: string;
    feedDeleteConfirm: string;
    entryUpdateFailed: string;
    entryLoadFailed: string;
    entryNotFound: string;
  };

  // Tool calls
  toolCalls: {
    moreSteps: (count: number) => string;
    lessSteps: string;
    executeCommand: string;
    presentFiles: string;
    needYourHelp: string;
    useTool: (toolName: string) => string;
    searchForRelatedInfo: string;
    searchForRelatedImages: string;
    searchFor: (query: string) => string;
    searchForRelatedImagesFor: (query: string) => string;
    searchOnWebFor: (query: string) => string;
    viewWebPage: string;
    listFolder: string;
    readFile: string;
    writeFile: string;
    clickToViewContent: string;
    writeTodos: string;
    skillInstallTooltip: string;
  };

  // Uploads
  uploads: {
    uploading: string;
    uploadingFiles: string;
  };

  // Subtasks
  subtasks: {
    subtask: string;
    executing: (count: number) => string;
    in_progress: string;
    completed: string;
    failed: string;
  };

  // Settings
  settings: {
    title: string;
    description: string;
    sections: {
      appearance: string;
      memory: string;
      tools: string;
      channels: string;
      skills: string;
      notification: string;
      about: string;
    };
    memory: {
      title: string;
      description: string;
      empty: string;
      rawJson: string;
      markdown: {
        overview: string;
        userContext: string;
        work: string;
        personal: string;
        topOfMind: string;
        historyBackground: string;
        recentMonths: string;
        earlierContext: string;
        longTermBackground: string;
        updatedAt: string;
        facts: string;
        empty: string;
        table: {
          category: string;
          confidence: string;
          confidenceLevel: {
            veryHigh: string;
            high: string;
            normal: string;
            unknown: string;
          };
          content: string;
          source: string;
          createdAt: string;
          view: string;
        };
      };
    };
    appearance: {
      themeTitle: string;
      themeDescription: string;
      system: string;
      light: string;
      dark: string;
      systemDescription: string;
      lightDescription: string;
      darkDescription: string;
      languageTitle: string;
      languageDescription: string;
    };
    tools: {
      title: string;
      description: string;
    };
    channels: {
      title: string;
      description: string;
    };
    models: {
      title: string;
      description: string;
    };
    sandbox: {
      title: string;
      description: string;
    };
    modelPage: SettingsModelPageTranslations;
    toolPage: SettingsToolPageTranslations;
    skillPage: SettingsSkillPageTranslations;
    workbenchPluginsPage: SettingsWorkbenchPluginsPageTranslations;
    configSections: {
      models: SettingsConfigModelsTranslations;
      tools: SettingsConfigToolsSectionTranslations;
      memory: SettingsConfigMemoryTranslations;
      sandbox: SettingsConfigSandboxTranslations;
      subagents: SettingsConfigSubagentsTranslations;
      summarization: SettingsConfigSummarizationTranslations;
      rss: SettingsConfigRssTranslations;
      environmentVariables: SettingsConfigEnvironmentVariablesTranslations;
      title: SettingsConfigTitleTranslations;
      saveBar: SettingsConfigSaveBarTranslations;
      fieldTip: SettingsConfigFieldTipTranslations;
    };
    skillImportDialog: SettingsSkillImportDialogTranslations;
    validation: SettingsValidationTranslations;
    retrieval: Record<string, unknown>;
    skills: {
      title: string;
      description: string;
      createSkill: string;
      emptyTitle: string;
      emptyDescription: string;
      emptyButton: string;
    };
    notification: {
      title: string;
      description: string;
      requestPermission: string;
      deniedHint: string;
      testButton: string;
      testTitle: string;
      testBody: string;
      notSupported: string;
      disableNotification: string;
    };
    acknowledge: {
      emptyTitle: string;
      emptyDescription: string;
    };
    workbenchPlugins: {
      title: string;
      description: string;
      installed: string;
      marketplace: string;
      addPlugin: string;
      createViaSkill: string;
      uploadPackage: string;
      uploading: string;
      uploadFormatError: string;
      uploadFailed: string;
      pluginInstalled: string;
      pluginDeleted: string;
      deleteFailed: string;
      deleteConfirmTitle: string;
      deleteConfirmDescription: string;
      cancelAction: string;
      confirmDeleteAction: string;
      emptyTitle: string;
      emptyDescription: string;
      emptyButton: string;
    };
  };
}
