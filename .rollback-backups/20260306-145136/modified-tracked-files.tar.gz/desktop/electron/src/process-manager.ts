import { app } from "electron";
import { ChildProcess, spawn, spawnSync } from "node:child_process";
import { createWriteStream, existsSync, WriteStream } from "node:fs";
import path from "node:path";
import { isPortInUse, waitForHttp, waitForPort } from "./health";
import { LocalProxyServer } from "./local-proxy";
import type { DesktopRuntimePaths } from "./paths";

type ServiceName = "langgraph" | "gateway" | "frontend" | "proxy";

interface ManagedService {
  name: ServiceName;
  child: ChildProcess;
  logStream: WriteStream;
  logPath: string;
}

export interface DesktopRuntimePorts {
  frontendPort: number;
  gatewayPort: number;
  langgraphPort: number;
  proxyPort: number;
}

export interface DesktopStartupObserver {
  onStageStart?: (stage: string) => void;
  onStageSuccess?: (stage: string) => void;
  onStageFailure?: (stage: string, error: unknown) => void;
}

export class DesktopProcessManager {
  private services: Map<ServiceName, ManagedService> = new Map();
  private localProxy: LocalProxyServer | null = null;
  private ports: DesktopRuntimePorts | null = null;

  constructor(
    private paths: DesktopRuntimePaths,
    private observer?: DesktopStartupObserver
  ) {}

  async startup(): Promise<DesktopRuntimePorts> {
    try {
      // 阶段 1：分配端口
      this.notifyStage("runtime.assign-ports");
      this.ports = await this.assignPorts();
      this.notifySuccess("runtime.assign-ports");

      // 阶段 1.5：校验端口可用（避免误连旧进程导致前端配置错乱）
      this.notifyStage("runtime.check-ports");
      await this.checkPortsAvailable();
      this.notifySuccess("runtime.check-ports");

      // 阶段 2：检查依赖
      this.notifyStage("runtime.check-dependencies");
      await this.checkDependencies();
      this.notifySuccess("runtime.check-dependencies");

      // 阶段 3：启动 LangGraph
      this.notifyStage("runtime.start.langgraph");
      await this.startLangGraph();
      this.notifySuccess("runtime.start.langgraph");

      // 阶段 4：启动 Gateway
      this.notifyStage("runtime.start.gateway");
      await this.startGateway();
      this.notifySuccess("runtime.start.gateway");

      // 阶段 5：启动 Frontend
      this.notifyStage("runtime.start.frontend");
      await this.startFrontend();
      this.notifySuccess("runtime.start.frontend");

      // 阶段 6：启动代理层（同源入口）
      this.notifyStage("runtime.start.proxy");
      await this.startProxy();
      this.notifySuccess("runtime.start.proxy");

      return this.ports;
    } catch (error) {
      await this.shutdown();
      throw error;
    }
  }

  private async assignPorts(): Promise<DesktopRuntimePorts> {
    // 使用固定端口（与 Makefile 保持一致）
    return {
      langgraphPort: 2024,
      gatewayPort: 8001,
      frontendPort: 3000,
      proxyPort: 2026,
    };
  }

  private async checkDependencies(): Promise<void> {
    if (app.isPackaged) {
      this.assertPackagedRuntime();
      return;
    }

    // 开发模式依赖：uv + pnpm + nginx
    const uvCheck = spawnSync("uv", ["--version"], { stdio: "ignore" });
    if (uvCheck.error || uvCheck.status !== 0) {
      throw new Error("uv not found. Please install: curl -LsSf https://astral.sh/uv/install.sh | sh");
    }
    const pnpmCheck = spawnSync("pnpm", ["--version"], { stdio: "ignore" });
    if (pnpmCheck.error || pnpmCheck.status !== 0) {
      throw new Error("pnpm not found. Please install: npm install -g pnpm");
    }
    const nginxCheck = spawnSync("nginx", ["-v"], { stdio: "ignore" });
    if (nginxCheck.error || nginxCheck.status !== 0) {
      throw new Error("nginx not found. Please install nginx before starting desktop dev");
    }
  }

  private assertPackagedRuntime(): void {
    const requiredPaths = [
      this.paths.runtimeManifestPath,
      this.paths.backendCwd,
      this.paths.frontendCwd,
      this.paths.frontendServerEntry ?? "",
      this.paths.pythonExecutable ?? "",
    ].filter(Boolean);

    const missing = requiredPaths.filter((entry) => !existsSync(entry));
    if (missing.length > 0) {
      throw new Error(`Packaged runtime is incomplete: ${missing.join(", ")}`);
    }
  }

  private async checkPortsAvailable(): Promise<void> {
    if (!this.ports) {
      throw new Error("Ports not assigned");
    }

    const checks = await Promise.all([
      isPortInUse(this.ports.langgraphPort),
      isPortInUse(this.ports.gatewayPort),
      isPortInUse(this.ports.frontendPort),
      isPortInUse(this.ports.proxyPort),
    ]);
    const inUsePorts = [
      checks[0] ? this.ports.langgraphPort : null,
      checks[1] ? this.ports.gatewayPort : null,
      checks[2] ? this.ports.frontendPort : null,
      checks[3] ? this.ports.proxyPort : null,
    ].filter((port): port is number => port !== null);

    if (inUsePorts.length > 0) {
      throw new Error(`Port conflict detected: ${inUsePorts.join(", ")}`);
    }
  }

  private async startLangGraph(): Promise<void> {
    const logPath = path.join(this.paths.logsDir, "langgraph.log");
    const logStream = createWriteStream(logPath, { flags: "a" });

    const env = {
      ...process.env,
      NION_HOME: this.paths.appDataDir, // 关键：设置 NION_HOME
      NO_COLOR: "1"
    };

    const child = app.isPackaged
      ? spawn(
          this.paths.pythonExecutable!,
          [
            "-m",
            "langgraph",
            "dev",
            "--no-browser",
            "--allow-blocking",
            "--no-reload",
            "--host",
            "0.0.0.0",
            "--port",
            String(this.ports!.langgraphPort),
          ],
          {
            cwd: this.paths.backendCwd,
            env,
            stdio: ["ignore", "pipe", "pipe"],
          },
        )
      : spawn(
          "uv",
          ["run", "langgraph", "dev", "--no-browser", "--allow-blocking", "--no-reload"],
          {
            cwd: this.paths.backendCwd,
            env,
            stdio: ["ignore", "pipe", "pipe"],
          },
        );

    child.stdout?.pipe(logStream);
    child.stderr?.pipe(logStream);

    this.services.set("langgraph", { name: "langgraph", child, logStream, logPath });

    // 等待服务启动
    await waitForPort(this.ports!.langgraphPort, 30000);
  }

  private async startGateway(): Promise<void> {
    const logPath = path.join(this.paths.logsDir, "gateway.log");
    const logStream = createWriteStream(logPath, { flags: "a" });

    const env = {
      ...process.env,
      NION_HOME: this.paths.appDataDir // 关键：设置 NION_HOME
    };

    const child = app.isPackaged
      ? spawn(
          this.paths.pythonExecutable!,
          ["-m", "uvicorn", "src.gateway.app:app", "--host", "0.0.0.0", "--port", String(this.ports!.gatewayPort)],
          {
            cwd: this.paths.backendCwd,
            env,
            stdio: ["ignore", "pipe", "pipe"],
          },
        )
      : spawn(
          "uv",
          ["run", "uvicorn", "src.gateway.app:app", "--host", "0.0.0.0", "--port", String(this.ports!.gatewayPort)],
          {
            cwd: this.paths.backendCwd,
            env,
            stdio: ["ignore", "pipe", "pipe"],
          },
        );

    child.stdout?.pipe(logStream);
    child.stderr?.pipe(logStream);

    this.services.set("gateway", { name: "gateway", child, logStream, logPath });

    // 等待服务启动
    await waitForHttp(`http://localhost:${this.ports!.gatewayPort}/health`, 30000);
  }

  private async startFrontend(): Promise<void> {
    const logPath = path.join(this.paths.logsDir, "frontend.log");
    const logStream = createWriteStream(logPath, { flags: "a" });

    const env = {
      ...process.env,
      // 统一走同源代理入口，避免跨域问题
      NEXT_PUBLIC_LANGGRAPH_BASE_URL: `http://localhost:${this.ports!.proxyPort}/api/langgraph`,
      NEXT_PUBLIC_BACKEND_BASE_URL: `http://localhost:${this.ports!.proxyPort}`,
      SKIP_ENV_VALIDATION: "1", // 跳过环境变量验证
    };

    const child = app.isPackaged
      ? spawn(
          process.execPath,
          [this.paths.frontendServerEntry!],
          {
            cwd: this.paths.frontendCwd,
            env: {
              ...env,
              ELECTRON_RUN_AS_NODE: "1",
              NODE_ENV: "production",
              PORT: String(this.ports!.frontendPort),
              HOSTNAME: "127.0.0.1",
            },
            stdio: ["ignore", "pipe", "pipe"],
          },
        )
      : spawn(
          "pnpm",
          ["run", "dev"],
          {
            cwd: this.paths.frontendCwd,
            env,
            stdio: ["ignore", "pipe", "pipe"],
          },
        );

    child.stdout?.pipe(logStream);
    child.stderr?.pipe(logStream);

    this.services.set("frontend", { name: "frontend", child, logStream, logPath });

    // 等待服务启动（HTTP 层可访问）
    await waitForPort(this.ports!.frontendPort, app.isPackaged ? 30000 : 60000);
    await waitForHttp(`http://localhost:${this.ports!.frontendPort}`, 30000);
  }

  private async startProxy(): Promise<void> {
    if (app.isPackaged) {
      this.localProxy = new LocalProxyServer(this.ports!);
      await this.localProxy.start();
      await waitForPort(this.ports!.proxyPort, 10000);
      return;
    }

    await this.startDevNginxProxy();
  }

  private async startDevNginxProxy(): Promise<void> {
    const confPath = path.join(this.paths.repoRoot, "docker", "nginx", "nginx.local.conf");
    if (!existsSync(confPath)) {
      throw new Error(`nginx config not found: ${confPath}`);
    }

    const logPath = path.join(this.paths.logsDir, "proxy.log");
    const logStream = createWriteStream(logPath, { flags: "a" });

    const child = spawn(
      "nginx",
      ["-g", "daemon off;", "-c", confPath, "-p", this.paths.repoRoot],
      {
        cwd: this.paths.repoRoot,
        env: process.env,
        stdio: ["ignore", "pipe", "pipe"],
      },
    );

    child.stdout?.pipe(logStream);
    child.stderr?.pipe(logStream);

    this.services.set("proxy", { name: "proxy", child, logStream, logPath });
    await waitForPort(this.ports!.proxyPort, 30000);
    await waitForHttp(`http://localhost:${this.ports!.proxyPort}/health`, 30000);
  }

  async shutdown(): Promise<void> {
    if (this.localProxy) {
      try {
        await this.localProxy.stop();
      } catch (error) {
        console.error("Failed to stop local proxy:", error);
      } finally {
        this.localProxy = null;
      }
    }

    if (!app.isPackaged) {
      const confPath = path.join(this.paths.repoRoot, "docker", "nginx", "nginx.local.conf");
      if (existsSync(confPath)) {
        spawnSync("nginx", ["-c", confPath, "-p", this.paths.repoRoot, "-s", "quit"], {
          stdio: "ignore",
        });
      }
    }

    for (const [name, service] of this.services) {
      try {
        service.child.kill("SIGTERM");
        service.logStream.end();
      } catch (error) {
        console.error(`Failed to stop ${name}:`, error);
      }
    }
    this.services.clear();
  }

  private notifyStage(stage: string): void {
    this.observer?.onStageStart?.(stage);
  }

  private notifySuccess(stage: string): void {
    this.observer?.onStageSuccess?.(stage);
  }
}
